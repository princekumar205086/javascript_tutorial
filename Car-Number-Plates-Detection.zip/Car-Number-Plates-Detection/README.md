# Car-Number-Plates-Detection
prerequisite - python, anaconda, code editor(vscode/pycharm)

step-1 - install opencv, easyocr

step-2 - create conda environment using:- **conda create -n number python=3.10 -y**
-----------------number is just environment name-------------------------------

step-3 - activate environment using:- **conda activate number**

------------------Run app and experience its feature----------------------------




